

var target = document.querySelectorAll('[data-anime]');
var target2 = document.querySelectorAll('[data-anime2]');
var animationClass = 'animate';


function scrollMouse() {

    var janela = window.pageYOffset + ((window.innerHeight * 4) / 4.5);
  
    target.forEach(function(element) {

        if((janela) > 1235) {
            element.classList.add(animationClass);
        }
        
        else {
            element.classList.remove(animationClass);
        }

    });

    target2.forEach(function(element) {

      if((janela) > 1950) {
          element.classList.add(animationClass);
      }
      
      else {
          element.classList.remove(animationClass);
      }

  })

} scrollMouse();

if(target.length) {

window.addEventListener('scroll', function() {

    scrollMouse();

})

};









const typedTextSpan = document.querySelector(".typed-text");
const cursorSpan = document.querySelector(".cursor");

const textArray = ["espaguetes", "pizzas", "lasanhas", "risotos"];
const typingDelay = 100;
const erasingDelay = 50;
const newTextDelay = 1000; // Delay between current and next text
let textArrayIndex = 0;
let charIndex = 0;

function type() {
  if (charIndex < textArray[textArrayIndex].length) {
    if(!cursorSpan.classList.contains("typing")) cursorSpan.classList.add("typing");
    typedTextSpan.textContent += textArray[textArrayIndex].charAt(charIndex);
    charIndex++;
    setTimeout(type, typingDelay);
  } 
  else {
    cursorSpan.classList.remove("typing");
    setTimeout(erase, newTextDelay);
  }
}

function erase() {
  if (charIndex > 0) {
    if(!cursorSpan.classList.contains("typing")) cursorSpan.classList.add("typing");
    typedTextSpan.textContent = textArray[textArrayIndex].substring(0, charIndex-1);
    charIndex--;
    setTimeout(erase, erasingDelay);
  } 
  else {
    cursorSpan.classList.remove("typing");
    textArrayIndex++;
    if(textArrayIndex>=textArray.length) textArrayIndex=0;
    setTimeout(type, typingDelay + 1100);
  }
}

document.addEventListener("DOMContentLoaded", function() { // On DOM Load initiate the effect
  if(textArray.length) setTimeout(type, newTextDelay + 250);
});

















var btnA = document.querySelector('.menu')

var nav = document.querySelector('.menuOpc')
var conteudo = document.querySelector('.conteudoOpc')


btnA.addEventListener('click', function(){

    if(nav.style.animationName == 'animacao'){

      setTimeout(function(){
        conteudo.style.display = 'none'
      }, 400);

      nav.style.animationName = 'animacaoContrario'

    }
    
    else if(nav.style.animationName == 'animacaoContrario'){

      nav.style.animationName = ''

    }

});

btnA.addEventListener('click', function(){

    if(nav.style.animationName == ''){

      conteudo.style.display = 'block'

      nav.style.animationName = 'animacao'

    }

});


function fecharMenu(){

  if(nav.style.animationName == 'animacao'){

    setTimeout(function(){
      conteudo.style.display = 'none'
    }, 400);

    nav.style.animationName = 'animacaoContrario'

  }
  
  else if(nav.style.animationName == 'animacaoContrario'){

    nav.style.animationName = ''

  }

  var check = document.querySelector('.inpCH')
  
  check.checked = false

}